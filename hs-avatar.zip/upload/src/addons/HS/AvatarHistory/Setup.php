<?php

namespace HS\AvatarHistory;

use XF\AddOn\AbstractSetup;
use XF\AddOn\StepRunnerInstallTrait;
use XF\AddOn\StepRunnerUninstallTrait;
use XF\AddOn\StepRunnerUpgradeTrait;

class Setup extends AbstractSetup
{
    use StepRunnerInstallTrait;
    use StepRunnerUpgradeTrait;
    use StepRunnerUninstallTrait;

    public function installStep1()
    {
        $schemaManager = $this->schemaManager();

        $schemaManager->createTable('xf_hs_avatar_history', function(\XF\Db\Schema\Create $table)
        {
            $table->addColumn('history_id', 'int')->autoIncrement();
            $table->addColumn('user_id', 'int')->unsigned();
            $table->addColumn('rel_path', 'varchar', 255);
            $table->addColumn('file_size', 'int')->unsigned()->setDefault(0);
            $table->addColumn('file_hash', 'varchar', 32)->setDefault('');
            $table->addColumn('created_at', 'int')->unsigned()->setDefault(0);
            $table->addPrimaryKey('history_id');
            $table->addKey('user_id');
        });
    }

    public function uninstallStep1()
    {
        $this->schemaManager()->dropTable('xf_hs_avatar_history');
    }

    public function postInstall(array &$stateChanges)
    {
        // Gelecekte kullanılabilecek işlemler için boş bırakıldı.
        // Event dinleyicisi Listener.php dosyasında tanımlanır.
    }
}
