<?php

namespace HS\AvatarHistory\Repository;

use XF\Mvc\Entity\Repository;

class AvatarHistory extends Repository
{
    /**
     * Belirli bir kullanıcının avatar geçmişini getirir.
     */
    public function findByUser(int $userId)
    {
        return $this->finder('HS:AvatarHistory')
            ->where('user_id', $userId)
            ->order('created_at', 'DESC');
    }

    /**
     * En fazla N kayıt tutar, fazlasını siler.
     */
    public function pruneToLimit(int $userId, int $limit)
    {
        if ($limit < 1)
        {
            return;
        }

        $ids = $this->db()->fetchAllColumn(
            $this->db()->limit(
                'SELECT history_id FROM xf_hs_avatar_history WHERE user_id = ? ORDER BY created_at DESC',
                $limit
            ),
            $userId
        );

        if (!$ids)
        {
            return;
        }

        $in = implode(',', array_map('intval', $ids));
        $toDelete = $this->db()->fetchAll(
            "SELECT history_id, rel_path FROM xf_hs_avatar_history
             WHERE user_id = ? AND history_id NOT IN ($in)
             ORDER BY created_at ASC",
            $userId
        );

        foreach ($toDelete as $row)
        {
            try
            {
                \XF::app()->fs()->delete('data://' . $row['rel_path']);
            }
            catch (\Throwable $e)
            {
                // Dosya yoksa sessiz geç
            }

            $this->db()->delete('xf_hs_avatar_history', 'history_id = ?', $row['history_id']);
        }
    }
}
