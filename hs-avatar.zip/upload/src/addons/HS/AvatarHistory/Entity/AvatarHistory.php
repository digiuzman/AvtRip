<?php

namespace HS\AvatarHistory\Entity;

use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;

class AvatarHistory extends Entity
{
    public static function getStructure(Structure $structure)
    {
        $structure->table = 'xf_hs_avatar_history';
        $structure->shortName = 'HS:AvatarHistory';
        $structure->primaryKey = 'history_id';

        $structure->columns = [
            'history_id' => ['type' => self::UINT, 'autoIncrement' => true],
            'user_id'    => ['type' => self::UINT, 'required' => true],
            'rel_path'   => ['type' => self::STR,  'required' => true, 'maxLength' => 255],
            'file_size'  => ['type' => self::UINT, 'default' => 0],
            'file_hash'  => ['type' => self::BINARY, 'maxLength' => 20, 'nullable' => true],
            'created_at' => ['type' => self::UINT, 'default' => \XF::$time],
        ];

        $structure->relations = [
            'User' => [
                'entity' => 'XF:User',
                'type'   => self::TO_ONE,
                'conditions' => 'user_id',
                'primary' => true
            ]
        ];

        // Repository sınıfını doğru belirtelim
        $structure->repositoryClass = 'HS\\AvatarHistory\\Repository\\AvatarHistory';

        return $structure;
    }

    public function getPublicUrl(): string
    {
        return \XF::app()->applyExternalDataUrl($this->rel_path);
    }
}
