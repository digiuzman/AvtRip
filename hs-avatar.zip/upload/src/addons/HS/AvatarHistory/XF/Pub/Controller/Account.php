<?php

namespace HS\AvatarHistory\XF\Pub\Controller;

use XF\Mvc\ParameterBag;

class Account extends XFCP_Account
{
    public function actionAvatar(ParameterBag $params)
    {
        $reply = parent::actionAvatar($params);

        $visitor = \XF::visitor();

        if ($visitor->user_id)
        {
            $repo = $this->repository('HS:AvatarHistory');
            $avatars = $repo->findByUser($visitor->user_id)->fetch();

            $reply->setParam('avatarHistory', $avatars);
        }

        return $reply;
    }
}
