<?php

namespace HS\AvatarHistory\XF\Service\User;

class Avatar extends XFCP_Avatar
{
    public function applyAvatar(\XF\Http\Upload $upload = null, $type = 'custom')
    {
        $visitor = \XF::visitor();

        // Mevcut avatarı yedekle
        if ($visitor && $visitor->user_id && $visitor->avatar_date)
        {
            $filePath = sprintf('avatars/o/%d/%d.jpg',
                floor($visitor->user_id / 1000),
                $visitor->user_id
            );

            $src = \XF::getRootDirectory() . '/data/' . $filePath;

            if (file_exists($src))
            {
                $date = time();
                $relDir = "hs_avatar_history/{$visitor->user_id}";
                $relPath = "{$relDir}/avatar_{$date}.jpg";

                $fs = \XF::app()->fs();
                $fs->ensureDir("data://{$relDir}");
                $fs->copyFile("data://{$filePath}", "data://{$relPath}");

                $db = \XF::db();
                $db->insert('xf_hs_avatar_history', [
                    'user_id'    => $visitor->user_id,
                    'rel_path'   => $relPath,
                    'file_size'  => filesize($src),
                    'file_hash'  => md5_file($src),
                    'created_at' => $date
                ]);

                // Eski kayıtları limitle
                \XF::repository('HS:AvatarHistory')->pruneToLimit(
                    $visitor->user_id,
                    \XF::options()->hsAvatarHistoryMax ?? 20
                );
            }
        }

        // Sonra normal akışı devam ettir
        return parent::applyAvatar($upload, $type);
    }
}
