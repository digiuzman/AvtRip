<?php

namespace HS\AvatarHistory;

use XF\Entity\User;

class Listener
{
    /**
     * Kullanıcı silindiğinde geçmişi temizle
     */
    public static function userDelete(User $user)
    {
        $db = \XF::db();
        $fs = \XF::app()->fs();

        $entries = $db->fetchAll('SELECT rel_path FROM xf_hs_avatar_history WHERE user_id = ?', $user->user_id);

        foreach ($entries as $entry)
        {
            try
            {
                $fs->delete('data://' . $entry['rel_path']);
            }
            catch (\Throwable $e)
            {
                // Dosya zaten silinmişse sorun etme
            }
        }

        $db->delete('xf_hs_avatar_history', 'user_id = ?', $user->user_id);

        // Klasörü de temizle
        $fs->deleteDir("data://hs_avatar_history/{$user->user_id}");
    }
}
